import React, { useState, useEffect, useRef } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, updateDoc, onSnapshot, collection, query, where, addDoc, getDocs, deleteDoc } from 'firebase/firestore';
import { getAnalytics } from "firebase/analytics";
export const initialAuthToken = window.__initial_auth_token ?? null;//typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;

const firebaseConfig = {
  apiKey: "AIzaSyCCMPM8ow6VknwU6SELDDpJWagXj1RtrqU",
  authDomain: "showgame777-d1b56.firebaseapp.com",
  projectId: "showgame777-d1b56",
  storageBucket: "showgame777-d1b56.firebasestorage.app",
  messagingSenderId: "639640082964",
  appId: "1:639640082964:web:a2e945105be2ed6a602501",
  measurementId: "G-MQ26H0VE1S"
};
export const APP_ID  =firebaseConfig.appId
// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const db = getFirestore(app);
export const auth = getAuth(app);